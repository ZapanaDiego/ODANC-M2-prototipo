/* ==========================================================================
   ODANC Arequipa · Prototipo v0.2
   Módulo 1 funcional: cálculo de días hábiles, feriados, reloj y persistencia.
   Sin dependencias externas.
   ========================================================================== */

(() => {
  'use strict';

  const APP_VERSION = '0.2';
  const MAX_DIAS_HABILES = 5000;
  const STORAGE = {
    feriados: 'odanc.proto.feriados.v1',
    reloj: 'odanc.proto.reloj.v1',
    calculo: 'odanc.proto.calculo.v1'
  };

  const ROUTES = {
    plazos: {
      title: 'Módulo 1 · Calculadora de Plazos',
      subtitle: 'Cómputo de días hábiles para procedimientos disciplinarios'
    },
    documentos: {
      title: 'Módulo 2 · Autogenerador Documental',
      subtitle: 'Borradores institucionales a partir de las fechas calculadas'
    }
  };

  const DEFAULT_ROUTE = 'plazos';
  const FERIADOS_FIJOS = [
    [1, 1, 'Año Nuevo'],
    [5, 1, 'Día del Trabajo'],
    [6, 7, 'Batalla de Arica y Día de la Bandera'],
    [6, 29, 'San Pedro y San Pablo'],
    [7, 23, 'Día de la Fuerza Aérea del Perú'],
    [7, 28, 'Fiestas Patrias'],
    [7, 29, 'Fiestas Patrias (Desfile Militar)'],
    [8, 4, 'Día del Juez y la Jueza'],
    [8, 6, 'Batalla de Junín'],
    [8, 15, 'Aniversario de Arequipa (Ley N.° 24875)'],
    [8, 30, 'Santa Rosa de Lima'],
    [10, 8, 'Combate de Angamos'],
    [11, 1, 'Día de Todos los Santos'],
    [12, 8, 'Inmaculada Concepción'],
    [12, 9, 'Batalla de Ayacucho'],
    [12, 25, 'Navidad']
  ];

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const estado = {
    reloj: { manual: false, fecha: '' },
    feriados: [],
    calculo: null
  };

  let toastTimer = null;
  let focoAnteriorModal = null;
  let calculoDescartado = false;
  let almacenamientoDisponible = true;
  let avisoAlmacenamientoMostrado = false;

  /* ------------------------------------------------------------------ */
  /* Fechas                                                              */
  /* ------------------------------------------------------------------ */

  const pad2 = (value) => String(value).padStart(2, '0');

  function fechaISO(date) {
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
  }

  function hoyISO() {
    return fechaISO(new Date());
  }

  function esFechaISO(valor) {
    if (typeof valor !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(valor)) return false;
    const [anio, mes, dia] = valor.split('-').map(Number);
    const fecha = new Date(anio, mes - 1, dia, 12, 0, 0, 0);
    return fecha.getFullYear() === anio
      && fecha.getMonth() === mes - 1
      && fecha.getDate() === dia;
  }

  function aFecha(iso) {
    if (!esFechaISO(iso)) return null;
    const [anio, mes, dia] = iso.split('-').map(Number);
    return new Date(anio, mes - 1, dia, 12, 0, 0, 0);
  }

  function sumarDias(fecha, dias) {
    return new Date(
      fecha.getFullYear(),
      fecha.getMonth(),
      fecha.getDate() + dias,
      12,
      0,
      0,
      0
    );
  }

  function diferenciaDias(desde, hasta) {
    const a = Date.UTC(desde.getFullYear(), desde.getMonth(), desde.getDate());
    const b = Date.UTC(hasta.getFullYear(), hasta.getMonth(), hasta.getDate());
    return Math.round((b - a) / 86_400_000);
  }

  function esFinDeSemana(fecha) {
    const dia = fecha.getDay();
    return dia === 0 || dia === 6;
  }

  function fechaVisible(iso) {
    if (!esFechaISO(iso)) return iso || '';
    const [anio, mes, dia] = iso.split('-');
    return `${dia}/${mes}/${anio}`;
  }

  function fechaLarga(fecha) {
    const texto = new Intl.DateTimeFormat('es-PE', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(fecha);
    return texto.charAt(0).toUpperCase() + texto.slice(1);
  }

  function fechaDocumento(fecha) {
    const meses = [
      'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
      'julio', 'agosto', 'setiembre', 'octubre', 'noviembre', 'diciembre'
    ];
    return `${fecha.getDate()} de ${meses[fecha.getMonth()]} de ${fecha.getFullYear()}`;
  }

  function calcularPascua(anio) {
    const a = anio % 19;
    const b = Math.floor(anio / 100);
    const c = anio % 100;
    const d = Math.floor(b / 4);
    const e = b % 4;
    const f = Math.floor((b + 8) / 25);
    const g = Math.floor((b - f + 1) / 3);
    const h = (19 * a + b - d - g + 15) % 30;
    const i = Math.floor(c / 4);
    const k = c % 4;
    const l = (32 + 2 * e + 2 * i - h - k) % 7;
    const m = Math.floor((a + 11 * h + 22 * l) / 451);
    const mes = Math.floor((h + l - 7 * m + 114) / 31);
    const dia = ((h + l - 7 * m + 114) % 31) + 1;
    return new Date(anio, mes - 1, dia, 12, 0, 0, 0);
  }

  /* ------------------------------------------------------------------ */
  /* Almacenamiento                                                      */
  /* ------------------------------------------------------------------ */

  function probarAlmacenamiento() {
    try {
      const clave = '__odanc_proto_test__';
      window.localStorage.setItem(clave, '1');
      window.localStorage.removeItem(clave);
      return true;
    } catch {
      return false;
    }
  }

  function leerJSON(clave, respaldo) {
    try {
      const valor = window.localStorage.getItem(clave);
      return valor === null ? respaldo : JSON.parse(valor);
    } catch {
      return respaldo;
    }
  }

  function guardarJSON(clave, valor) {
    try {
      window.localStorage.setItem(clave, JSON.stringify(valor));
      return true;
    } catch {
      almacenamientoDisponible = false;
      return false;
    }
  }

  function borrarJSON(clave) {
    try {
      window.localStorage.removeItem(clave);
    } catch {
      almacenamientoDisponible = false;
    }
  }

  function hashFeriados() {
    return estado.feriados
      .map((feriado) => `${feriado.fecha}|${feriado.categoria}`)
      .sort()
      .join('||');
  }

  function normalizarFeriado(valor) {
    if (!valor || !esFechaISO(valor.fecha)) return null;
    if (valor.categoria !== 'oficial' && valor.categoria !== 'contingencia') return null;

    return {
      id: typeof valor.id === 'string' && valor.id
        ? valor.id
        : `${valor.categoria}:${valor.fecha}`,
      fecha: valor.fecha,
      motivo: typeof valor.motivo === 'string' ? valor.motivo : '',
      categoria: valor.categoria,
      esPredeterminado: valor.esPredeterminado === true,
      movil: valor.movil === true,
      offsetPascua: Number.isInteger(valor.offsetPascua) ? valor.offsetPascua : null
    };
  }

  function esCalculoValido(calculo) {
    return Boolean(
      calculo
      && esFechaISO(calculo.fechaNotificacion)
      && esFechaISO(calculo.fechaVencimiento)
      && Number.isInteger(calculo.diasHabiles)
      && calculo.diasHabiles >= 1
      && calculo.diasHabiles <= MAX_DIAS_HABILES
      && Number.isFinite(calculo.diasNaturales)
      && typeof calculo.notificacionElectronica === 'boolean'
      && typeof calculo.feriadosHash === 'string'
    );
  }

  function cargarEstado() {
    estado.reloj = { manual: false, fecha: hoyISO() };

    const reloj = leerJSON(STORAGE.reloj, null);
    if (reloj && typeof reloj.manual === 'boolean' && esFechaISO(reloj.fecha)) {
      estado.reloj = {
        manual: reloj.manual,
        fecha: reloj.manual ? reloj.fecha : hoyISO()
      };
    }

    const feriados = leerJSON(STORAGE.feriados, []);
    if (Array.isArray(feriados)) {
      estado.feriados = feriados.map(normalizarFeriado).filter(Boolean);
    }

    const calculo = leerJSON(STORAGE.calculo, null);
    if (calculo) {
      if (esCalculoValido(calculo) && calculo.feriadosHash === hashFeriados()) {
        estado.calculo = calculo;
      } else {
        calculoDescartado = true;
        borrarJSON(STORAGE.calculo);
      }
    }
  }

  function guardarFeriados() {
    guardarJSON(STORAGE.feriados, estado.feriados);
  }

  function guardarReloj() {
    guardarJSON(STORAGE.reloj, estado.reloj);
  }

  function guardarCalculo() {
    if (estado.calculo) {
      guardarJSON(STORAGE.calculo, estado.calculo);
    } else {
      borrarJSON(STORAGE.calculo);
    }
  }

  /* ------------------------------------------------------------------ */
  /* Feriados base                                                       */
  /* ------------------------------------------------------------------ */

  function generarFeriadosBase(anio) {
    const lista = FERIADOS_FIJOS.map(([mes, dia, motivo]) => {
      const fecha = fechaISO(new Date(anio, mes - 1, dia, 12, 0, 0, 0));
      return {
        id: `base:${fecha}`,
        fecha,
        motivo,
        categoria: 'oficial',
        esPredeterminado: true,
        movil: false,
        offsetPascua: null
      };
    });

    const pascua = calcularPascua(anio);
    [[-3, 'Jueves Santo'], [-2, 'Viernes Santo']].forEach(([offset, motivo]) => {
      const fecha = fechaISO(sumarDias(pascua, offset));
      lista.push({
        id: `base:${fecha}`,
        fecha,
        motivo,
        categoria: 'oficial',
        esPredeterminado: true,
        movil: true,
        offsetPascua: offset
      });
    });

    return lista;
  }

  function agregarBaseSilencioso(anio, feriados = estado.feriados) {
    let agregados = 0;
    generarFeriadosBase(anio).forEach((feriado) => {
      if (!feriados.some((existente) => existente.fecha === feriado.fecha)) {
        feriados.push(feriado);
        agregados += 1;
      }
    });
    return agregados;
  }

  /* ------------------------------------------------------------------ */
  /* Motor de cálculo                                                    */
  /* ------------------------------------------------------------------ */

  function construirInhabiles(feriados) {
    const inhabiles = new Set();

    feriados.forEach((feriado) => {
      const fecha = aFecha(feriado.fecha);
      if (!fecha) return;

      // Un feriado oficial que cae en fin de semana no se traslada.
      if (feriado.categoria === 'oficial' && esFinDeSemana(fecha)) return;
      inhabiles.add(feriado.fecha);
    });

    return inhabiles;
  }

  function calcularPlazo(fechaNotificacion, diasHabiles, notificacionElectronica, feriados) {
    if (!esFechaISO(fechaNotificacion)) {
      throw new Error('La fecha de notificación no es válida.');
    }
    if (!Number.isInteger(diasHabiles) || diasHabiles < 1) {
      throw new Error('El plazo debe ser un número entero de días hábiles mayor a cero.');
    }
    if (diasHabiles > MAX_DIAS_HABILES) {
      throw new Error(`El plazo no puede superar los ${MAX_DIAS_HABILES} días hábiles.`);
    }

    const inicio = aFecha(fechaNotificacion);
    const inhabiles = construirInhabiles(feriados || []);
    const diasPrevios = notificacionElectronica ? 2 : 0;

    let previosPendientes = diasPrevios;
    let fechaEfectos = null;
    let fechaInicioPlazo = null;
    let habilesTranscurridos = 0;
    let cursor = inicio;
    let iteraciones = 0;

    while (habilesTranscurridos < diasHabiles) {
      iteraciones += 1;
      if (iteraciones > 250_000) {
        throw new Error('No se pudo calcular el plazo con el calendario actual.');
      }

      cursor = sumarDias(cursor, 1);
      const clave = fechaISO(cursor);

      if (esFinDeSemana(cursor) || inhabiles.has(clave)) continue;

      if (previosPendientes > 0) {
        previosPendientes -= 1;
        if (previosPendientes === 0) fechaEfectos = clave;
        continue;
      }

      if (fechaInicioPlazo === null) fechaInicioPlazo = clave;
      habilesTranscurridos += 1;
    }

    const diasNaturales = diferenciaDias(inicio, cursor);
    const semanas = Math.round((diasNaturales / 7) * 10) / 10;

    return {
      fechaVencimiento: fechaISO(cursor),
      diasNaturales,
      semanas,
      diasHabilesPrevios: diasPrevios,
      fechaEfectos,
      fechaInicioPlazo
    };
  }

  function calcularConCalendario(fechaNotificacion, diasHabiles, notificacionElectronica) {
    let resultado = calcularPlazo(
      fechaNotificacion,
      diasHabiles,
      notificacionElectronica,
      estado.feriados
    );

    const aniosAgregados = [];
    const hayBase = () => estado.feriados.some((feriado) => feriado.esPredeterminado);

    if (hayBase()) {
      for (let intento = 0; intento < 10; intento += 1) {
        const anioInicio = Number(fechaNotificacion.slice(0, 4));
        const anioVencimiento = Number(resultado.fechaVencimiento.slice(0, 4));
        let agregoAlguno = false;

        for (let anio = anioInicio; anio <= anioVencimiento; anio += 1) {
          const tieneBase = estado.feriados.some(
            (feriado) => feriado.esPredeterminado && Number(feriado.fecha.slice(0, 4)) === anio
          );
          if (tieneBase) continue;

          const agregados = agregarBaseSilencioso(anio);
          if (agregados > 0) {
            aniosAgregados.push(anio);
            agregoAlguno = true;
          }
        }

        if (!agregoAlguno) break;

        resultado = calcularPlazo(
          fechaNotificacion,
          diasHabiles,
          notificacionElectronica,
          estado.feriados
        );
      }
    }

    resultado.aniosAgregados = [...new Set(aniosAgregados)];

    const oficiales = estado.feriados.filter((feriado) => feriado.categoria === 'oficial').length;
    if (estado.feriados.length === 0) {
      resultado.aviso = 'No hay feriados cargados: el cálculo solo excluye fines de semana.';
    } else if (oficiales === 0) {
      resultado.aviso = 'No hay feriados oficiales cargados: solo se descontaron las contingencias registradas.';
    } else {
      resultado.aviso = null;
    }

    return resultado;
  }

  /* ------------------------------------------------------------------ */
  /* Render: reloj                                                       */
  /* ------------------------------------------------------------------ */

  function pintarReloj() {
    const fecha = aFecha(estado.reloj.fecha) || new Date();
    const visible = fechaVisible(estado.reloj.fecha);
    const larga = fechaLarga(fecha);

    const chipFecha = $('#chip-fecha');
    if (chipFecha) {
      chipFecha.textContent = visible;
      const chip = chipFecha.closest('.chip');
      if (chip) chip.title = larga;
    }

    const badge = $('#badge-modo-manual');
    if (badge) badge.hidden = !estado.reloj.manual;

    const banner = $('#banner-fecha-manual');
    if (banner) banner.hidden = !estado.reloj.manual;

    document.body.classList.toggle('manual-activo', estado.reloj.manual);

    const textoFechaManual = $('#texto-fecha-manual');
    if (textoFechaManual) textoFechaManual.textContent = visible;

    const alertaModal = $('#modal-alerta-manual');
    if (alertaModal) alertaModal.hidden = !estado.reloj.manual;

    const btnDesactivarModal = $('#btn-desactivar-manual');
    if (btnDesactivarModal) btnDesactivarModal.hidden = !estado.reloj.manual;

    const textoBase = $('#texto-feriados-base');
    if (textoBase) textoBase.textContent = `Cargar feriados base ${fecha.getFullYear()}`;

    $$('[data-fecha-documento]').forEach((elemento) => {
      elemento.textContent = `Arequipa, ${fechaDocumento(fecha)}`;
    });
  }

  /* ------------------------------------------------------------------ */
  /* Render: feriados                                                    */
  /* ------------------------------------------------------------------ */

  function crearTituloGrupo(contenedor, texto) {
    const titulo = document.createElement('div');
    titulo.className = 'holiday-group-title';
    titulo.textContent = texto;
    contenedor.appendChild(titulo);
  }

  function crearListaVacia(contenedor, texto) {
    const vacio = document.createElement('div');
    vacio.className = 'holiday-empty';
    vacio.textContent = texto;
    contenedor.appendChild(vacio);
  }

  function crearChipFeriado(feriado, esProyectado = false) {
    const chip = document.createElement('div');
    chip.className = `holiday-chip${esProyectado ? ' is-projected' : ''}`;

    const fecha = document.createElement('span');
    fecha.className = 'holiday-chip-date';
    fecha.textContent = fechaVisible(feriado.fecha);

    const motivo = document.createElement('span');
    motivo.className = 'holiday-chip-reason';
    motivo.textContent = feriado.motivo || 'Sin descripción';

    const idEliminar = esProyectado ? feriado.idOriginal : feriado.id;
    const boton = document.createElement('button');
    boton.type = 'button';
    boton.className = 'holiday-chip-remove';
    boton.setAttribute(
      'aria-label',
      esProyectado
        ? `Eliminar el feriado original del ${fechaVisible(feriado.fechaOriginal)}`
        : `Eliminar el registro del ${fechaVisible(feriado.fecha)}`
    );
    boton.title = esProyectado
      ? `Eliminar el feriado original del ${fechaVisible(feriado.fechaOriginal)}`
      : 'Eliminar registro';
    boton.innerHTML = '<svg class="i" aria-hidden="true"><use href="#xmark"></use></svg>';
    boton.addEventListener('click', () => eliminarFeriado(idEliminar));

    if (esProyectado) {
      chip.title = `Proyección ${feriado.fecha.slice(0, 4)} del feriado original del ${fechaVisible(feriado.fechaOriginal)}`;
    }

    chip.append(fecha, motivo, boton);
    return chip;
  }

  function proximaOcurrencia(feriado, referencia) {
    const anio = referencia.getFullYear();
    let candidato;

    if (feriado.movil && Number.isInteger(feriado.offsetPascua)) {
      candidato = sumarDias(calcularPascua(anio), feriado.offsetPascua);
    } else {
      const original = aFecha(feriado.fecha);
      if (!original) return null;
      candidato = new Date(anio, original.getMonth(), original.getDate(), 12, 0, 0, 0);
    }

    if (candidato < referencia) {
      // Siguiente ocurrencia anual exacta, sin desfase por años bisiestos.
      if (feriado.movil && Number.isInteger(feriado.offsetPascua)) {
        candidato = sumarDias(calcularPascua(anio + 1), feriado.offsetPascua);
      } else {
        const original = aFecha(feriado.fecha);
        candidato = new Date(anio + 1, original.getMonth(), original.getDate(), 12, 0, 0, 0);
      }
    }

    return fechaISO(candidato);
  }

  function pintarFeriados() {
    const contOficiales = $('#lista-feriados-oficiales');
    const contContingencias = $('#lista-feriados-contingencias');
    const badgeOficial = $('#badge-count-oficial');
    const badgeContingencia = $('#badge-count-contingencia');

    if (!contOficiales || !contContingencias) return;

    const referencia = aFecha(estado.reloj.fecha) || new Date();
    const oficiales = estado.feriados.filter((feriado) => feriado.categoria === 'oficial');
    const contingencias = estado.feriados.filter((feriado) => feriado.categoria === 'contingencia');

    if (badgeOficial) badgeOficial.textContent = String(oficiales.length);
    if (badgeContingencia) badgeContingencia.textContent = String(contingencias.length);

    contOficiales.replaceChildren();
    contContingencias.replaceChildren();

    const fechasOficiales = new Set(oficiales.map((feriado) => feriado.fecha));
    const actuales = oficiales
      .filter((feriado) => (aFecha(feriado.fecha) || referencia) >= referencia)
      .sort((a, b) => a.fecha.localeCompare(b.fecha));
    const pasados = oficiales
      .filter((feriado) => (aFecha(feriado.fecha) || referencia) < referencia)
      .sort((a, b) => a.fecha.localeCompare(b.fecha));

    const proyectados = new Map();
    const fechasProyectadas = new Set();
    const idsProyectados = new Set();

    pasados.forEach((feriado) => {
      const fechaProyectada = proximaOcurrencia(feriado, referencia);
      if (!fechaProyectada) return;
      if (fechasOficiales.has(fechaProyectada)) return;
      if (fechasProyectadas.has(fechaProyectada)) return;

      fechasProyectadas.add(fechaProyectada);
      idsProyectados.add(feriado.id);

      const anioProyeccion = fechaProyectada.slice(0, 4);
      if (!proyectados.has(anioProyeccion)) proyectados.set(anioProyeccion, []);

      proyectados.get(anioProyeccion).push({
        ...feriado,
        fecha: fechaProyectada,
        fechaOriginal: feriado.fecha,
        idOriginal: feriado.id,
        esProyectado: true
      });
    });

    if (actuales.length > 0) {
      crearTituloGrupo(contOficiales, 'Próximos feriados');
      actuales.forEach((feriado) => contOficiales.appendChild(crearChipFeriado(feriado)));
    }

    [...proyectados.keys()].sort().forEach((anio) => {
      crearTituloGrupo(contOficiales, `Proyección ${anio}`);
      proyectados.get(anio)
        .sort((a, b) => a.fecha.localeCompare(b.fecha))
        .forEach((feriado) => contOficiales.appendChild(crearChipFeriado(feriado, true)));
    });

    const transcurridos = pasados.filter((feriado) => !idsProyectados.has(feriado.id));
    if (transcurridos.length > 0) {
      crearTituloGrupo(contOficiales, 'Transcurridos');
      transcurridos
        .sort((a, b) => b.fecha.localeCompare(a.fecha))
        .forEach((feriado) => contOficiales.appendChild(crearChipFeriado(feriado)));
    }

    if (actuales.length === 0 && proyectados.size === 0 && transcurridos.length === 0) {
      crearListaVacia(
        contOficiales,
        'No hay feriados cargados para este año. Use «Cargar feriados base» o agregue uno manualmente.'
      );
    }

    const proximas = contingencias
      .filter((feriado) => (aFecha(feriado.fecha) || referencia) >= referencia)
      .sort((a, b) => a.fecha.localeCompare(b.fecha));
    const pasadas = contingencias
      .filter((feriado) => (aFecha(feriado.fecha) || referencia) < referencia)
      .sort((a, b) => b.fecha.localeCompare(a.fecha));

    if (proximas.length > 0) {
      crearTituloGrupo(contContingencias, 'Próximas');
      proximas.forEach((feriado) => contContingencias.appendChild(crearChipFeriado(feriado)));
    }

    if (pasadas.length > 0) {
      crearTituloGrupo(contContingencias, 'Transcurridas');
      pasadas.forEach((feriado) => contContingencias.appendChild(crearChipFeriado(feriado)));
    }

    if (contingencias.length === 0) {
      crearListaVacia(contContingencias, 'Sin contingencias ni suspensiones registradas.');
    }

    pintarAvisoCalendario();
  }

  function pintarAvisoCalendario() {
    const aviso = $('#aviso-calendario');
    if (!aviso) return;

    const oficiales = estado.feriados.filter((feriado) => feriado.categoria === 'oficial').length;

    if (estado.feriados.length === 0) {
      aviso.textContent = 'No hay feriados cargados: el cálculo solo excluirá fines de semana. Cargue los feriados base para un resultado exacto.';
      aviso.hidden = false;
    } else if (oficiales === 0) {
      aviso.textContent = 'No hay feriados oficiales cargados: solo se descontarán las contingencias registradas.';
      aviso.hidden = false;
    } else {
      aviso.hidden = true;
    }
  }

  /* ------------------------------------------------------------------ */
  /* Render: resultado y Módulo 2                                        */
  /* ------------------------------------------------------------------ */

  function pintarResultado(calculo) {
    const fechaEl = $('#resultado-fecha');
    const detalleEl = $('#resultado-detalle');
    const notificacionEl = $('#resultado-notificacion');
    const avisoEl = $('#resultado-aviso');

    if (!fechaEl || !detalleEl) return;

    if (!calculo) {
      fechaEl.textContent = '--/--/----';
      detalleEl.textContent = 'Pulse «Calcular Plazo Procesal» para obtener el resultado';
      if (notificacionEl) notificacionEl.hidden = true;
      if (avisoEl) avisoEl.hidden = true;
      return;
    }

    const fecha = aFecha(calculo.fechaVencimiento);
    if (!fecha) {
      pintarResultado(null);
      return;
    }

    const semanas = Number.isFinite(calculo.semanas)
      ? calculo.semanas
      : Math.round((calculo.diasNaturales / 7) * 10) / 10;

    fechaEl.textContent = fechaLarga(fecha);
    detalleEl.textContent = `+${calculo.diasNaturales} días naturales (~${Number(semanas).toFixed(1)} semanas)`;

    if (notificacionEl) {
      notificacionEl.hidden = !(calculo.notificacionElectronica && calculo.diasHabilesPrevios === 2);
    }

    if (avisoEl) {
      const avisos = [];
      if (Array.isArray(calculo.aniosAgregados) && calculo.aniosAgregados.length > 0) {
        avisos.push(`Se agregaron los feriados base ${calculo.aniosAgregados.join(', ')} para completar el cálculo.`);
      }
      if (calculo.aviso) avisos.push(calculo.aviso);

      if (avisos.length > 0) {
        avisoEl.textContent = avisos.join(' ');
        avisoEl.hidden = false;
      } else {
        avisoEl.hidden = true;
      }
    }
  }

  function pintarModulo2Fechas() {
    const notificacion = $('#doc-fecha-notificacion');
    const vencimiento = $('#doc-fecha-vencimiento');
    const dias = $('#doc-dias');
    const pill = $('#doc-fechas-pill');
    const texto = $('#doc-fechas-texto');

    if (!notificacion || !vencimiento || !dias) return;

    const calculo = estado.calculo;

    if (!calculo) {
      notificacion.textContent = '--/--/----';
      vencimiento.textContent = '--/--/----';
      dias.textContent = '15';
      if (pill) {
        pill.className = 'status-pill pending';
        pill.textContent = 'Sin cálculo';
      }
      if (texto) texto.textContent = 'Calcule un plazo en el Módulo 1.';
      return;
    }

    notificacion.textContent = fechaVisible(calculo.fechaNotificacion);
    vencimiento.textContent = fechaVisible(calculo.fechaVencimiento);
    dias.textContent = String(calculo.diasHabiles);

    if (pill) {
      pill.className = 'status-pill ok';
      pill.textContent = 'Calculado';
    }
    if (texto) texto.textContent = 'Fechas tomadas del último cálculo del Módulo 1.';
  }

  /* ------------------------------------------------------------------ */
  /* Acciones del Módulo 1                                               */
  /* ------------------------------------------------------------------ */

  function actualizarModalidadNotificacion() {
    const checkbox = $('#notificacion-electronica');
    if (!checkbox) return;

    const electronica = checkbox.checked;
    const label = $('#label-fecha-inicio');
    const ayuda = $('#ayuda-notificacion-electronica');
    const ayudaFecha = $('#ayuda-fecha-inicio');

    if (label) {
      label.textContent = electronica ? 'Fecha de ingreso a casilla electrónica' : 'Fecha de Notificación';
    }
    if (ayuda) {
      ayuda.textContent = electronica
        ? 'Ingrese la fecha de depósito en casilla. Se cuentan dos días hábiles previos y después el plazo solicitado.'
        : 'Al marcar, se aplican dos días hábiles previos al inicio del plazo.';
    }
    if (ayudaFecha) {
      ayudaFecha.textContent = electronica
        ? 'Fecha de depósito en la casilla electrónica.'
        : 'Fecha desde la cual se inicia el cómputo.';
    }
  }

  function invalidarResultado() {
    estado.calculo = null;
    guardarCalculo();
    pintarResultado(null);
    pintarModulo2Fechas();
  }

  function marcarInvalido(input, invalido) {
    if (!input) return;
    input.classList.toggle('is-invalid', invalido);
  }

  function manejarCalcular() {
    const fechaInput = $('#fecha-inicio');
    const diasInput = $('#dias-plazo');
    const checkbox = $('#notificacion-electronica');

    if (!fechaInput || !diasInput || !checkbox) return;

    marcarInvalido(fechaInput, false);
    marcarInvalido(diasInput, false);

    const fechaNotificacion = fechaInput.value;
    const diasTexto = diasInput.value.trim();
    const diasHabiles = Number(diasTexto);
    let primerInvalido = null;

    if (!fechaNotificacion || !esFechaISO(fechaNotificacion)) {
      marcarInvalido(fechaInput, true);
      primerInvalido = primerInvalido || fechaInput;
      showToast('Seleccione una fecha de notificación válida.');
    }

    if (diasTexto === '' || !Number.isInteger(diasHabiles) || diasHabiles < 1 || diasHabiles > MAX_DIAS_HABILES) {
      marcarInvalido(diasInput, true);
      primerInvalido = primerInvalido || diasInput;
      showToast(`Ingrese un número entero de días hábiles entre 1 y ${MAX_DIAS_HABILES}.`);
    }

    if (primerInvalido) {
      invalidarResultado();
      primerInvalido.focus();
      return;
    }

    try {
      const resultado = calcularConCalendario(
        fechaNotificacion,
        diasHabiles,
        checkbox.checked
      );

      if (resultado.aniosAgregados.length > 0) {
        guardarFeriados();
        pintarFeriados();
      }

      estado.calculo = {
        fechaNotificacion,
        diasHabiles,
        notificacionElectronica: checkbox.checked,
        fechaVencimiento: resultado.fechaVencimiento,
        diasNaturales: resultado.diasNaturales,
        semanas: resultado.semanas,
        diasHabilesPrevios: resultado.diasHabilesPrevios,
        fechaInicioPlazo: resultado.fechaInicioPlazo,
        fechaEfectos: resultado.fechaEfectos,
        aniosAgregados: resultado.aniosAgregados,
        aviso: resultado.aviso,
        feriadosHash: hashFeriados(),
        creadoEn: Date.now()
      };

      guardarCalculo();
      pintarResultado(estado.calculo);
      pintarModulo2Fechas();
      pintarAvisoCalendario();

      showToast(
        resultado.aniosAgregados.length > 0
          ? `Plazo calculado. Se agregaron los feriados base ${resultado.aniosAgregados.join(', ')}.`
          : 'Plazo calculado correctamente.'
      );
    } catch (error) {
      invalidarResultado();
      showToast(error instanceof Error ? error.message : 'No se pudo calcular el plazo.');
    }
  }

  function agregarFeriado() {
    const fechaInput = $('#fecha-inhabil');
    const tipoSelect = $('#tipo-inhabil');
    const motivoInput = $('#motivo-inhabil');

    if (!fechaInput || !tipoSelect || !motivoInput) return;

    const fecha = fechaInput.value;
    const categoria = tipoSelect.value === 'contingencia' ? 'contingencia' : 'oficial';
    const motivo = motivoInput.value.trim()
      || (categoria === 'contingencia' ? 'Corte de red / Suspensión' : 'Feriado Oficial');

    marcarInvalido(fechaInput, false);

    if (!fecha || !esFechaISO(fecha)) {
      marcarInvalido(fechaInput, true);
      fechaInput.focus();
      showToast('Seleccione una fecha válida.');
      return;
    }

    if (estado.feriados.some((feriado) => feriado.fecha === fecha)) {
      showToast('Ya existe un feriado o contingencia registrado para esa fecha.');
      return;
    }

    estado.feriados.push({
      id: `${categoria}:${fecha}`,
      fecha,
      motivo,
      categoria,
      esPredeterminado: false,
      movil: false,
      offsetPascua: null
    });

    guardarFeriados();
    invalidarResultado();
    pintarFeriados();
    fechaInput.value = '';
    motivoInput.value = '';
    fechaInput.focus();

    const dia = aFecha(fecha);
    const finDeSemana = dia && esFinDeSemana(dia);
    showToast(
      categoria === 'oficial' && finDeSemana
        ? 'Registro agregado. El feriado cae en fin de semana y no altera el cómputo.'
        : 'Día inhábil agregado correctamente.'
    );
  }

  function eliminarFeriado(id) {
    const indice = estado.feriados.findIndex((feriado) => feriado.id === id);
    if (indice < 0) return;

    const [eliminado] = estado.feriados.splice(indice, 1);
    guardarFeriados();
    invalidarResultado();
    pintarFeriados();
    showToast(`Registro eliminado: ${fechaVisible(eliminado.fecha)}.`);
  }

  function cargarFeriadosBase() {
    const fecha = aFecha(estado.reloj.fecha) || new Date();
    const anio = fecha.getFullYear();
    const agregados = agregarBaseSilencioso(anio);

    if (agregados === 0) {
      showToast(`Los feriados base ${anio} ya están cargados o sus fechas ya están registradas.`);
      return;
    }

    guardarFeriados();
    invalidarResultado();
    pintarFeriados();
    showToast(`Feriados base ${anio} cargados: ${agregados} nuevo(s).`);
  }

  function copiarFecha() {
    if (!estado.calculo) {
      showToast('Calcule un plazo antes de copiar la fecha.');
      return;
    }

    const texto = ($('#resultado-fecha')?.textContent || '').trim();
    if (!texto || texto.includes('--')) return;

    const confirmar = () => showToast('Fecha copiada al portapapeles.');

    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      navigator.clipboard.writeText(texto).then(confirmar).catch(() => copiarConSeleccion(texto, confirmar));
    } else {
      copiarConSeleccion(texto, confirmar);
    }
  }

  function copiarConSeleccion(texto, confirmar) {
    const area = document.createElement('textarea');
    area.value = texto;
    area.setAttribute('readonly', '');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.select();

    try {
      if (document.execCommand('copy')) confirmar();
      else showToast('No se pudo copiar automáticamente.');
    } catch {
      showToast('No se pudo copiar automáticamente.');
    } finally {
      area.remove();
    }
  }

  function usarEnModulo2() {
    if (!estado.calculo) {
      showToast('Calcule un plazo antes de enviarlo al Módulo 2.');
      return;
    }
    window.location.hash = '#/documentos';
  }

  /* ------------------------------------------------------------------ */
  /* Reloj manual                                                        */
  /* ------------------------------------------------------------------ */

  function abrirModalReloj() {
    const modal = $('#modal-reloj');
    const input = $('#input-fecha-manual');
    if (!modal || !input) return;

    focoAnteriorModal = document.activeElement instanceof HTMLElement
      ? document.activeElement
      : null;

    input.value = estado.reloj.fecha;
    marcarInvalido(input, false);
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    pintarReloj();

    window.requestAnimationFrame(() => {
      input.focus();
    });
  }

  function cerrarModalReloj() {
    const modal = $('#modal-reloj');
    if (!modal) return;

    modal.hidden = true;
    document.body.style.overflow = '';

    if (focoAnteriorModal && typeof focoAnteriorModal.focus === 'function') {
      focoAnteriorModal.focus();
    }
    focoAnteriorModal = null;
  }

  function activarFechaManual() {
    const input = $('#input-fecha-manual');
    if (!input) return;

    const fecha = input.value;
    if (!fecha || !esFechaISO(fecha)) {
      marcarInvalido(input, true);
      input.focus();
      showToast('Seleccione una fecha manual válida.');
      return;
    }

    marcarInvalido(input, false);
    estado.reloj = { manual: true, fecha };
    guardarReloj();

    const fechaInicio = $('#fecha-inicio');
    if (fechaInicio) {
      fechaInicio.value = fecha;
      marcarInvalido(fechaInicio, false);
    }

    invalidarResultado();
    pintarReloj();
    pintarFeriados();
    cerrarModalReloj();
    showToast(`Fecha manual activada: ${fechaVisible(fecha)}.`);
  }

  function desactivarFechaManual() {
    estado.reloj = { manual: false, fecha: hoyISO() };
    guardarReloj();

    const fechaInicio = $('#fecha-inicio');
    if (fechaInicio) {
      fechaInicio.value = estado.reloj.fecha;
      marcarInvalido(fechaInicio, false);
    }

    invalidarResultado();
    pintarReloj();
    pintarFeriados();
    cerrarModalReloj();
    showToast(`Fecha del equipo restaurada: ${fechaVisible(estado.reloj.fecha)}.`);
  }

  function revisarCambioDeDia() {
    if (estado.reloj.manual) return;

    const hoy = hoyISO();
    if (hoy === estado.reloj.fecha) return;

    estado.reloj.fecha = hoy;
    pintarReloj();
    pintarFeriados();
    pintarAvisoCalendario();
    showToast(`La fecha del equipo cambió a ${fechaVisible(hoy)}.`);
  }

  /* ------------------------------------------------------------------ */
  /* Navegación                                                          */
  /* ------------------------------------------------------------------ */

  function rutaDesdeHash() {
    return window.location.hash.replace(/^#\/?/, '').split('?')[0];
  }

  function reemplazarHash(hash) {
    try {
      window.history.replaceState(null, '', hash);
    } catch {
      window.location.hash = hash;
    }
  }

  function normalizarRuta() {
    const ruta = rutaDesdeHash();
    if (Object.prototype.hasOwnProperty.call(ROUTES, ruta)) return ruta;

    const hash = `#/${DEFAULT_ROUTE}`;
    if (window.location.hash !== hash) reemplazarHash(hash);
    return DEFAULT_ROUTE;
  }

  function actualizarNavegacion(ruta) {
    $$('[data-nav]').forEach((enlace) => {
      const activo = enlace.dataset.nav === ruta;
      enlace.classList.toggle('is-active', activo);
      if (activo) enlace.setAttribute('aria-current', 'page');
      else enlace.removeAttribute('aria-current');
    });
  }

  function render(ruta, enfocar = false) {
    const meta = ROUTES[ruta] || ROUTES[DEFAULT_ROUTE];

    $$('[data-page]').forEach((pagina) => {
      pagina.hidden = pagina.dataset.page !== ruta;
    });

    actualizarNavegacion(ruta);

    const titulo = $('#page-title');
    const subtitulo = $('#page-subtitle');
    if (titulo) titulo.textContent = meta.title;
    if (subtitulo) subtitulo.textContent = meta.subtitle;

    document.title = `${meta.title} · ODANC Arequipa`;

    if (ruta === 'documentos') pintarModulo2Fechas();

    if (enfocar) {
      const pagina = $(`[data-page="${ruta}"]`);
      const encabezado = pagina?.querySelector('h2');
      if (encabezado) {
        encabezado.setAttribute('tabindex', '-1');
        encabezado.focus({ preventScroll: true });
      }
      window.scrollTo({
        top: 0,
        behavior: prefersReducedMotion ? 'auto' : 'smooth'
      });
    }
  }

  function manejarCambioRuta() {
    render(normalizarRuta(), true);
  }

  /* ------------------------------------------------------------------ */
  /* Toasts                                                              */
  /* ------------------------------------------------------------------ */

  function showToast(mensaje, duracion = 3600) {
    const toast = $('#toast');
    if (!toast) return;

    toast.textContent = mensaje;
    toast.classList.add('is-visible');

    if (toastTimer !== null) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => {
      toast.classList.remove('is-visible');
      toastTimer = null;
    }, duracion);
  }

  /* ------------------------------------------------------------------ */
  /* Panel de pruebas (solo ?debug=1)                                    */
  /* ------------------------------------------------------------------ */

  function crearPanelDebug() {
    const base2026 = generarFeriadosBase(2026);
    const base2027 = generarFeriadosBase(2027);
    const ambas = [...base2026, ...base2027];
    const contingencia = [{ fecha: '2026-11-09', categoria: 'contingencia', motivo: 'Prueba' }];

    const lanza = (fn) => {
      try {
        fn();
        return false;
      } catch {
        return true;
      }
    };

    const pruebas = [
      [
        '14/09/2026 + 3 sin casilla = 17/09/2026',
        () => calcularPlazo('2026-09-14', 3, false, base2026).fechaVencimiento === '2026-09-17'
      ],
      [
        '14/09/2026 + 3 con casilla = 21/09/2026',
        () => {
          const r = calcularPlazo('2026-09-14', 3, true, base2026);
          return r.fechaVencimiento === '2026-09-21'
            && r.diasHabilesPrevios === 2
            && r.fechaEfectos === '2026-09-16'
            && r.fechaInicioPlazo === '2026-09-17';
        }
      ],
      [
        'Feriados 28 y 29/07 dentro del plazo',
        () => calcularPlazo('2026-07-27', 3, false, base2026).fechaVencimiento === '2026-08-03'
      ],
      [
        'Feriado 15/08 en sábado no se traslada',
        () => calcularPlazo('2026-08-14', 1, false, base2026).fechaVencimiento === '2026-08-17'
      ],
      [
        'Contingencia 09/11 se descuenta',
        () => calcularPlazo('2026-11-06', 1, false, contingencia).fechaVencimiento === '2026-11-10'
      ],
      [
        'Cruce de año con base 2026 y 2027',
        () => calcularPlazo('2026-12-24', 5, false, ambas).fechaVencimiento === '2027-01-04'
      ],
      [
        'Días naturales y semanas',
        () => {
          const r = calcularPlazo('2026-09-14', 3, false, []);
          return r.diasNaturales === 3 && r.semanas === 0.4;
        }
      ],
      [
        'Plazo 0 rechazado',
        () => lanza(() => calcularPlazo('2026-09-14', 0, false, base2026))
      ],
      [
        'Plazo mayor a 5000 rechazado',
        () => lanza(() => calcularPlazo('2026-09-14', 5001, false, base2026))
      ]
    ];

    const panel = document.createElement('section');
    panel.className = 'debug-panel';
    panel.setAttribute('aria-label', 'Panel de pruebas del motor');

    const cabecera = document.createElement('div');
    cabecera.className = 'debug-head';
    const titulo = document.createElement('strong');
    titulo.textContent = `Pruebas del motor · v${APP_VERSION}`;
    const nota = document.createElement('span');
    nota.textContent = 'Solo visible con ?debug=1';
    cabecera.append(titulo, nota);

    const tabla = document.createElement('table');
    tabla.className = 'debug-table';
    const thead = document.createElement('thead');
    const filaHead = document.createElement('tr');
    const thEstado = document.createElement('th');
    thEstado.textContent = 'Estado';
    const thPrueba = document.createElement('th');
    thPrueba.textContent = 'Caso';
    filaHead.append(thEstado, thPrueba);
    thead.appendChild(filaHead);
    tabla.appendChild(thead);

    const tbody = document.createElement('tbody');
    pruebas.forEach(([nombre, ejecutar]) => {
      let ok = false;
      try {
        ok = ejecutar() === true;
      } catch {
        ok = false;
      }

      const fila = document.createElement('tr');
      const estadoCelda = document.createElement('td');
      estadoCelda.className = ok ? 'debug-pass' : 'debug-fail';
      estadoCelda.textContent = ok ? 'PASS' : 'FAIL';
      const nombreCelda = document.createElement('td');
      nombreCelda.textContent = nombre;
      fila.append(estadoCelda, nombreCelda);
      tbody.appendChild(fila);
    });

    tabla.appendChild(tbody);
    panel.append(cabecera, tabla);
    document.body.appendChild(panel);
  }

  /* ------------------------------------------------------------------ */
  /* Inicialización                                                      */
  /* ------------------------------------------------------------------ */

  function inicializarFormulario() {
    const fechaInput = $('#fecha-inicio');
    const diasInput = $('#dias-plazo');
    const checkbox = $('#notificacion-electronica');

    if (estado.calculo) {
      if (fechaInput) fechaInput.value = estado.calculo.fechaNotificacion;
      if (diasInput) diasInput.value = String(estado.calculo.diasHabiles);
      if (checkbox) checkbox.checked = estado.calculo.notificacionElectronica;
      return;
    }

    if (fechaInput) fechaInput.value = estado.reloj.fecha;
    if (diasInput) diasInput.value = '15';
    if (checkbox) checkbox.checked = false;
  }

  function manejarClicDocumento(event) {
    const pendiente = event.target.closest('[data-pending]');
    if (pendiente) {
      event.preventDefault();
      showToast(pendiente.dataset.pending);
      return;
    }

    if (event.target.closest('[data-close-reloj]')) {
      cerrarModalReloj();
    }
  }

  function init() {
    almacenamientoDisponible = probarAlmacenamiento();
    cargarEstado();

    pintarReloj();
    inicializarFormulario();
    actualizarModalidadNotificacion();
    pintarFeriados();
    pintarAvisoCalendario();
    pintarResultado(estado.calculo);
    pintarModulo2Fechas();

    render(normalizarRuta(), false);

    $('#btn-calcular-plazo')?.addEventListener('click', manejarCalcular);
    $('#btn-feriados-base')?.addEventListener('click', cargarFeriadosBase);
    $('#btn-agregar-inhabil')?.addEventListener('click', agregarFeriado);
    $('#btn-copiar')?.addEventListener('click', copiarFecha);
    $('#btn-usar-modulo2')?.addEventListener('click', usarEnModulo2);

    $('#btn-abrir-reloj')?.addEventListener('click', abrirModalReloj);
    $('#btn-banner-cambiar')?.addEventListener('click', abrirModalReloj);
    $('#btn-banner-desactivar')?.addEventListener('click', desactivarFechaManual);
    $('#btn-activar-manual')?.addEventListener('click', activarFechaManual);
    $('#btn-desactivar-manual')?.addEventListener('click', desactivarFechaManual);
    $('#btn-cancelar-reloj')?.addEventListener('click', cerrarModalReloj);
    $('#btn-cerrar-modal-reloj')?.addEventListener('click', cerrarModalReloj);

    $('#fecha-inicio')?.addEventListener('input', () => {
      marcarInvalido($('#fecha-inicio'), false);
      invalidarResultado();
    });

    $('#dias-plazo')?.addEventListener('input', () => {
      marcarInvalido($('#dias-plazo'), false);
      invalidarResultado();
    });

    $('#notificacion-electronica')?.addEventListener('change', () => {
      actualizarModalidadNotificacion();
      invalidarResultado();
    });

    $('#dias-plazo')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        manejarCalcular();
      }
    });

    $('#motivo-inhabil')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        agregarFeriado();
      }
    });

    $('#input-fecha-manual')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        activarFechaManual();
      }
    });

    document.addEventListener('click', manejarClicDocumento);
    window.addEventListener('hashchange', manejarCambioRuta);

    document.addEventListener('keydown', (event) => {
      const modal = $('#modal-reloj');
      if (event.key === 'Escape' && modal && !modal.hidden) {
        cerrarModalReloj();
      }
    });

    window.setInterval(revisarCambioDeDia, 60_000);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) revisarCambioDeDia();
    });

    if (new URLSearchParams(window.location.search).has('debug')) {
      crearPanelDebug();
    }

    if (calculoDescartado) {
      window.setTimeout(() => {
        showToast('El último cálculo se descartó porque el calendario de feriados cambió.');
      }, 500);
    }

    if (!almacenamientoDisponible && !avisoAlmacenamientoMostrado) {
      avisoAlmacenamientoMostrado = true;
      window.setTimeout(() => {
        showToast('El navegador bloqueó el almacenamiento. El prototipo funcionará solo en memoria.', 5200);
      }, 700);
    }

    console.info(`ODANC Arequipa · prototipo v${APP_VERSION}`);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
