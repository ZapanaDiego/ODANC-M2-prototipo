/* ==========================================================================
   ODANC Arequipa · Prototipo v0.1
   Navegación, fecha de referencia y avisos de funciones pendientes.
   Sin dependencias externas.
   ========================================================================== */

(() => {
  'use strict';

  const APP_VERSION = '0.1';

  const ROUTES = {
    inicio: {
      title: 'Inicio',
      subtitle: 'Resumen del prototipo y hoja de ruta'
    },
    plazos: {
      title: 'Módulo 1 · Calculadora de Plazos',
      subtitle: 'Cómputo de días hábiles para procedimientos disciplinarios'
    },
    documentos: {
      title: 'Módulo 2 · Autogenerador Documental',
      subtitle: 'Borradores institucionales a partir de las fechas calculadas'
    },
    legal: {
      title: 'Base Legal',
      subtitle: 'Directorio normativo de consulta rápida'
    },
    config: {
      title: 'Configuración',
      subtitle: 'Estado del prototipo y opciones del sistema'
    }
  };

  const DEFAULT_ROUTE = 'inicio';
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  let toastTimer = null;
  let lastToday = '';

  /* ------------------------------------------------------------------ */
  /* Fechas                                                              */
  /* ------------------------------------------------------------------ */

  const pad2 = (value) => String(value).padStart(2, '0');

  function formatNumeric(date) {
    return `${pad2(date.getDate())}/${pad2(date.getMonth() + 1)}/${date.getFullYear()}`;
  }

  function formatISO(date) {
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
  }

  function formatLong(date) {
    const formatted = new Intl.DateTimeFormat('es-PE', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(date);
    return formatted.charAt(0).toUpperCase() + formatted.slice(1);
  }

  function formatDocumentDate(date) {
    const months = [
      'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
      'julio', 'agosto', 'setiembre', 'octubre', 'noviembre', 'diciembre'
    ];
    return `${date.getDate()} de ${months[date.getMonth()]} de ${date.getFullYear()}`;
  }

  function refreshDates() {
    const now = new Date();
    const numeric = formatNumeric(now);
    const iso = formatISO(now);
    const long = formatLong(now);
    const documentDate = formatDocumentDate(now);

    if (numeric === lastToday) return;
    lastToday = numeric;

    const chipDate = $('#chip-fecha');
    if (chipDate) {
      chipDate.textContent = numeric;
      const chip = chipDate.closest('.chip');
      if (chip) chip.title = long;
    }

    const startDate = $('#inicio-fecha');
    if (startDate) {
      startDate.textContent = numeric;
      startDate.title = long;
    }

    $$('[data-today-iso]').forEach((input) => {
      input.value = iso;
    });

    $$('[data-today-numeric]').forEach((element) => {
      element.textContent = numeric;
    });

    $$('[data-today-long]').forEach((element) => {
      element.textContent = long;
    });

    $$('[data-today-doc]').forEach((element) => {
      element.textContent = `Arequipa, ${documentDate}`;
    });
  }

  /* ------------------------------------------------------------------ */
  /* Navegación                                                          */
  /* ------------------------------------------------------------------ */

  function routeFromHash() {
    return location.hash.replace(/^#\/?/, '').split('?')[0];
  }

  function replaceHash(hash) {
    try {
      history.replaceState(null, '', hash);
    } catch {
      // Algunos navegadores restringen replaceState en file://; el hash directo sigue funcionando.
      location.hash = hash;
    }
  }

  function normalizeRoute() {
    const route = routeFromHash();
    if (Object.prototype.hasOwnProperty.call(ROUTES, route)) return route;

    const hash = `#/${DEFAULT_ROUTE}`;
    if (location.hash !== hash) replaceHash(hash);
    return DEFAULT_ROUTE;
  }

  function updateActiveNav(route) {
    $$('[data-nav]').forEach((link) => {
      const isActive = link.dataset.nav === route;
      link.classList.toggle('is-active', isActive);
      if (isActive) {
        link.setAttribute('aria-current', 'page');
      } else {
        link.removeAttribute('aria-current');
      }
    });
  }

  function render(route, focusPage = false) {
    const meta = ROUTES[route] || ROUTES[DEFAULT_ROUTE];

    $$('[data-page]').forEach((page) => {
      page.hidden = page.dataset.page !== route;
    });

    updateActiveNav(route);

    const title = $('#page-title');
    const subtitle = $('#page-subtitle');
    if (title) title.textContent = meta.title;
    if (subtitle) subtitle.textContent = meta.subtitle;

    document.title = `${meta.title} · ODANC Arequipa`;

    const activePage = $(`[data-page="${route}"]`);
    if (focusPage && activePage) {
      const heading = activePage.querySelector('h2');
      if (heading) {
        heading.setAttribute('tabindex', '-1');
        heading.focus({ preventScroll: true });
      }
      window.scrollTo({
        top: 0,
        behavior: prefersReducedMotion ? 'auto' : 'smooth'
      });
    }
  }

  function handleRouteChange() {
    const route = normalizeRoute();
    render(route, true);
  }

  /* ------------------------------------------------------------------ */
  /* Avisos                                                              */
  /* ------------------------------------------------------------------ */

  function showToast(message, duration = 3600) {
    const toast = $('#toast');
    if (!toast) return;

    toast.textContent = message;
    toast.classList.add('is-visible');

    if (toastTimer !== null) {
      window.clearTimeout(toastTimer);
    }

    toastTimer = window.setTimeout(() => {
      toast.classList.remove('is-visible');
      toastTimer = null;
    }, duration);
  }

  /* ------------------------------------------------------------------ */
  /* Interacciones                                                       */
  /* ------------------------------------------------------------------ */

  function handleDocumentClick(event) {
    const pending = event.target.closest('[data-pending]');
    if (pending) {
      event.preventDefault();
      showToast(pending.dataset.pending);
      return;
    }

    const logout = event.target.closest('[data-action="logout"]');
    if (logout) {
      event.preventDefault();
      showToast('Sesión simulada: este prototipo no incluye autenticación.');
    }
  }

  function init() {
    document.documentElement.dataset.appVersion = APP_VERSION;

    refreshDates();
    window.setInterval(refreshDates, 60_000);

    document.addEventListener('click', handleDocumentClick);
    window.addEventListener('hashchange', handleRouteChange);

    render(normalizeRoute(), false);

    // Si la pestaña permaneció abierta durante el cambio de día, actualiza al volver.
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) refreshDates();
    });

    console.info(`ODANC Arequipa · prototipo v${APP_VERSION}`);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
